package com.example.EmployeeManagementCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementCrudApplication.class, args);
	}

}
